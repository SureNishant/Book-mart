-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2021 at 06:21 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `novel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_password` varchar(20) NOT NULL,
  `admin_username` varchar(25) NOT NULL,
  `admin_record_inserted` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_password`, `admin_username`, `admin_record_inserted`) VALUES
(1, 'sure', 'nishant', 'nishant'),
(2, 'sharmasharma', 'rohit', 'nishant'),
(3, 'rahulrahul', 'rahul', 'rohit'),
(4, 'joshijoshi', 'saumya', 'nishant'),
(5, 'vatsal1234', 'vatsal', 'saumya'),
(6, 'qwertyuiop', 'qwertyu', 'nishant');

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `a_id` int(11) NOT NULL,
  `a_name` varchar(20) NOT NULL,
  `a_img` varchar(50) NOT NULL,
  `a_email` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `lastmodify_adminname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`a_id`, `a_name`, `a_img`, `a_email`, `description`, `lastmodify_adminname`) VALUES
(1, 'chetan bhagat', 'chetan bhagat.jpg', 'chetanbhagat@gmail.com', 'i m chetan', 'nishant'),
(2, 'amrita pritam', 'amrita pritam.jpg', 'amrita@gmail.com', '', 'saumya'),
(3, 'arundhati roy', 'arundhati roy.jpg', 'arundhati@gmail.com', '	', 'saumya'),
(4, 'jhumpa lahiri', 'jhumpa lahiri.jpg', 'jhumpa@gmail.com', '	', 'saumya'),
(5, 'r k narayan', 'r k narayan.jpg', 'narayan@gmail.com', '	', 'saumya'),
(6, 'rabindranath tagore', 'Rabindranath Tagore.jpg', 'tagore@gmail.com', '	', 'saumya'),
(7, 'ruskin bond', 'ruskin bond.jpg', 'bond@gmail.com', '	', 'saumya'),
(8, 'vikram seth', 'vikram seth.jpg', 'vikram@gmail.com', '	', 'saumya'),
(9, 'kushwant singh', 'Khushwant SingH.jpg', 'ksingh@gmail.com', '	', 'saumya'),
(10, 'ayn rand', 'ayn rand.jpg', 'aynrand@gmail.com', 'i am ayn rand', 'nishant');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_no` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `receivers_name` varchar(255) NOT NULL,
  `receivers_address` text NOT NULL,
  `receivers_phoneno` bigint(20) NOT NULL,
  `buying_date` date NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `grand_total` float NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pincode` int(11) NOT NULL,
  `confirm_adminname` varchar(255) NOT NULL,
  `deliverydone` varchar(255) DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_no`, `c_id`, `receivers_name`, `receivers_address`, `receivers_phoneno`, `buying_date`, `payment_method`, `grand_total`, `state`, `city`, `pincode`, `confirm_adminname`, `deliverydone`) VALUES
(7, 3, 'qwerty', 'qwerty', 9909990639, '2021-04-27', '', 800, 'gujarat', 'ahedaabd', 380008, 'monty', 'yes'),
(8, 3, 'ZXCVBNM', 'ZXCVBNM', 9909990639, '2021-04-27', '', 620, 'GUJARAT', 'AHMEDABAD', 123456, 'nishant21', 'yes'),
(9, 3, 'qwertyu', 'qwertyu', 1234568790, '2021-04-27', '', 800, 'qwertyu', 'qwertyu', 123456, 'nishant21', 'yes'),
(10, 3, 'as', 'as', 9876543210, '2021-04-27', '', 350, 'as', 'as', 123457, 'nishant21', 'yes'),
(11, 4, 'aa', 'aa', 1234567890, '2021-04-27', '', 350, 'aa', 'aa', 123456, 'nishant21', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `bill_book`
--

CREATE TABLE `bill_book` (
  `bill_no` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `p_quantity` int(111) NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill_book`
--

INSERT INTO `bill_book` (`bill_no`, `book_id`, `p_quantity`, `amount`) VALUES
(7, 3, 1, 350),
(7, 8, 1, 450),
(8, 9, 1, 300),
(8, 15, 1, 320),
(9, 3, 1, 350),
(9, 8, 1, 450),
(10, 10, 1, 350),
(11, 11, 1, 350);

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `book_name` varchar(30) NOT NULL,
  `b_author` varchar(255) NOT NULL,
  `b_publisher` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `genre` varchar(30) NOT NULL,
  `imbdrating` float NOT NULL,
  `book_img` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `totalavailable_quantity` int(11) NOT NULL,
  `lastmodify_adminname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `book_name`, `b_author`, `b_publisher`, `price`, `genre`, `imbdrating`, `book_img`, `description`, `totalavailable_quantity`, `lastmodify_adminname`) VALUES
(1, 'half girlfriend  ', 'chetan bhagat ', 'chetan', 200, 'love', 9, 'half girlfriend.jpg', 'i m half \r\n	', 100, 'nishant'),
(2, 'one indian girl  ', 'chetan bhagat ', 'chetan bhagat', 300, 'love', 9, 'one indian girl.jpg', 'one indian girl \r\n	', 100, 'nishant'),
(3, 'revolution 2020  ', 'chetan bhagat ', 'chetan bhagat', 350, 'adventure', 8, 'revolution 2020.jpg', 'evolution of life \r\n	', 100, 'nishant'),
(4, 'The Girl in Room 105  ', 'chetan bhagat ', 'chetan bhagat', 400, 'thriller', 8, 'The girl in room 105.jpg', 'the girl in room 105\r\n	', 100, 'nishant'),
(5, 'what young india wants', 'chetan bhagat', 'chetan bhagat', 450, 'current affairs', 8, 'what young india wants.jpg', '	', 1, 'saumya'),
(6, '3 mistakes of my life', 'chetan bhagat', 'chetan bhagat', 350, 'biography', 8, '3 Mistakes of My Life.jpg', '	', 1, 'saumya'),
(7, 'pinjar', 'amrita pritam', 'amrita pritam', 360, 'thriller', 8.5, 'Pinjar.jpg', '	', 0, 'saumya'),
(8, 'the god of small things', 'arundhati roy', 'arundhati roy', 450, 'friction', 9, 'The god of small things.jpg', '	', -1, 'saumya'),
(9, 'the friend', 'jhumpa lahiri', 'jhumpa lahiri', 300, 'relationship', 8, 'The Friend.jpg', '	', 0, 'saumya'),
(10, 'train to pakistan', 'kushwant singh', 'kushwant singh', 350, 'history', 8.5, 'Train to Pakistan.jpg', '	', 0, 'saumya'),
(11, 'indian thought', 'r k narayan', 'r k narayan', 350, 'thoughtness', 8, 'indian Thought.jpg', '	', 0, 'saumya'),
(12, 'waiting for the mahatma', 'r k narayan', 'r k narayan', 450, 'history', 9, 'waiting for the mahatma.jpg', '	', 1, 'saumya'),
(13, 'my boyhood days ', 'rabindranath tagore', 'rabindranath tagore', 500, 'biography', 9, 'my boyhood days.jpg', '	', 1, 'saumya'),
(14, 'ghost trouble', 'ruskin bond', 'ruskin bond', 300, 'thriller', 8, 'ghost trouble.jpg', '	', 1, 'saumya'),
(15, 'the ghost', 'ruskin bond', 'ruskin bond', 320, 'thriller', 8.5, 'the ghost.jpg', '	', 0, 'saumya'),
(16, 'the great train journey', 'ruskin bond', 'ruskin bond', 450, 'adventure', 9, 'the Great train Journey.jpg', '	', 1, 'saumya'),
(17, 'the perfect murder', 'ruskin bond', 'ruskin bond', 300, 'thriller', 8, 'The Perfect Murder.jpg', '	', 1, 'saumya'),
(18, 'the tree lover', 'ruskin bond', 'ruskin bond', 350, 'environment', 9, 'the tree lover.jpg', '	', 1, 'saumya'),
(19, 'upon an old wall dreaming', 'ruskin bond', 'ruskin bond', 450, 'thoughtness', 8, 'upon an old wall dreaming.jpg', '	', 1, 'saumya'),
(20, 'A SUITABLE BOY', 'VIKRAM SETH', 'VIKRAM SETH', 350, 'LIFE', 8.5, 'a Suitable boy.jpg', '	', 1, 'saumya'),
(21, 'THE GOLDEN GATE', 'VIKRAM SETH', 'VIKRAM SETH', 450, 'HISTORY', 9, 'the golden gate.jpg', '	', 1, 'saumya'),
(22, 'the india i love', 'ruskin bond', 'ruskin bond', 500, 'love', 9, 'the india i love.jpg', 'this book is written by ruskin bond', 1, 'nishant'),
(23, 'india positive', 'chetan bhagat', 'chetan', 300, 'documentary', 8, 'india positive.jpg', 'this book is written by chetan bhagat', 1, 'nishant');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `c_id` int(10) NOT NULL,
  `book_id` int(11) NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`c_id`, `book_id`, `p_quantity`, `amount`) VALUES
(4, 2, 1, 300),
(3, 3, 3, 1050);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(10) NOT NULL,
  `c_email` varchar(255) NOT NULL,
  `c_username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_email`, `c_username`, `password`) VALUES
(2, 'sure.nishant@gmail.com', 'nishant', 'suresure'),
(3, 'suremonty@gmail.com', 'monty', 'montymonty'),
(4, 'sure.nishant21@gmail.com', 'nishant21', 'qwertyuiop');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bill_no`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `bill_book`
--
ALTER TABLE `bill_book`
  ADD KEY `bill_no` (`bill_no`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `c_id` (`c_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bill_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`);

--
-- Constraints for table `bill_book`
--
ALTER TABLE `bill_book`
  ADD CONSTRAINT `bill_book_ibfk_1` FOREIGN KEY (`bill_no`) REFERENCES `bill` (`bill_no`),
  ADD CONSTRAINT `bill_book_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
