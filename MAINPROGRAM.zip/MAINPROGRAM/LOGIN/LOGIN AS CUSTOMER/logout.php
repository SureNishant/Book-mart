<?php

session_start();
session_destroy();


header('location:/MAINPROGRAM/HOMEPAGE/home1.php');


?>